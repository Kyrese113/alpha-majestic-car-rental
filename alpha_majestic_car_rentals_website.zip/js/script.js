
document.getElementById("bookingForm").addEventListener("submit", function(event){

let phone = document.getElementById("phone").value;

let pattern = /^[0-9]{7,10}$/;

if(!pattern.test(phone)){
alert("Please enter a valid phone number");
event.preventDefault();
}

});
